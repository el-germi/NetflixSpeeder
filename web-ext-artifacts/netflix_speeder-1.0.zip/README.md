# NetflixSpeeder
Adds playback speed seelctors to netflix
